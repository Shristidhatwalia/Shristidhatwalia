module.exports = {
   content: ["src/**/*.jsx"],
  theme: {
    extend: {},
  },
  plugins: [],
}
