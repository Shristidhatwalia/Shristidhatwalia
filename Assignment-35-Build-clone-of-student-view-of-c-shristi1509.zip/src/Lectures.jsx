import React from 'react';
import MainLayout from "./MainLayout";
import lectureData from "./mockdata/lecture"

function Lectures() {
  return (
      <div className="p-20 bg-green-500 h-full">lec
      </div>
  );
}

export default Lectures;