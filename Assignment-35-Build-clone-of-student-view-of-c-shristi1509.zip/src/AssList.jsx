import React from 'react';
import MainLayout from './MainLayout';

function AssList() {
  return (
      <div className="p-20 bg-red-500 h-full">assignment
      </div>
  );
}

export default AssList;