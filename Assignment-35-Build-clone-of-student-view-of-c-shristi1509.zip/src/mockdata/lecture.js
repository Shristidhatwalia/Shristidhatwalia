const lectureData=[
  {
    id: 1,
    topics:[
      {a1:"first",
      a2:"second"}
    ],
    recordingUrl:"https://google.com",
      duration:"03:45:20"
  },
{
    id: 2,
    topics:[
      {a1:"first",
      a2:"second"}
    ],
    recordingUrl:"https://google.com",
      duration:"03:45:20"
  },
  {
    id: 3,
    topics:[
       {a1:"first",
      a2:"second"}
    ],
    recordingUrl:"https://google.com",
      duration:"03:45:20"
  },
  {
    id: 4,
    topics:[
       {a1:"first",
      a2:"second"}
    ],
    recordingUrl:"https://google.com",
      duration:"03:45:20"
  },
  {
    id: 5,
    topics:[
       {a1:"first",
      a2:"second"}
    ],
    recordingUrl:"https://google.com",
      duration:"03:45:20"
  },
]

export default lectureData;