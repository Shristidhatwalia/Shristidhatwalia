import React from 'react';
import AssList from "./AssList";
import Lectures from "./Lectures";
import Quiz from "./Quiz";
import MainLayout from "./MainLayout";
import NotFound from "./NotFound";

import { Routes , Route, Navigate } from 'react-router-dom';

function App() {
  return (
    <div className="h-screen">
      
      <Routes> 
        <Route path="/" element={<Navigate to="/lectures"/>}></Route>
        <Route path="/" element={<MainLayout/>}>
        <Route path="assignments" element={<AssList/>}/>
        <Route path="lectures" element={<Lectures/>}/>
          </Route>
        <Route path="quiz" element={<Quiz/>}/>

        <Route path="*" element={<NotFound/>}></Route>
      </Routes>    
    </div>
  );
}

export default App;