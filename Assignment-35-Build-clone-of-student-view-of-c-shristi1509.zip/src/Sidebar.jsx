import React from 'react';
import {Link} from 'react-router-dom';

function Sidebar() {
  return (
    <div className="w-60 p-3 bg-gray-700 flex flex-col space-y-5 p-3">
         <Link to="/lectures" className="text-white font-bold">Lectures</Link>
         <Link to="/assignments" className="text-white font-bold">Assignments</Link>
         <Link to="/quiz" className="text-white font-bold">Quiz</Link>
      </div>
  );
}

export default Sidebar;