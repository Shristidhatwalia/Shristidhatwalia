import React from 'react';
import Sidebar from "./Sidebar";
import {Outlet} from 'react-router-dom';

function MainLayout(props) {
  return (
       <div className="flex h-full items-stretch"> 
     <Sidebar/>
         <div className="p-2 bg-pink-900 grow"><Outlet/></div>
       </div>
  );
}

export default MainLayout;