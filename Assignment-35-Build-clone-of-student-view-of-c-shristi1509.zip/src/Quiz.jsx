import React from 'react';

function Quiz() {
  return (
    <div> quiz</div>
  );
}

export default Quiz;