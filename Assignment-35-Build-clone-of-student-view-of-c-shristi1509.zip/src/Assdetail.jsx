import React from 'react';

function Assdetail() {
  return (
    <div></div>
  );
}

export default Assdetail;