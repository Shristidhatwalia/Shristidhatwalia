import React from 'react';

function NotFound() {
  return (
    <div>
      <h1 className="text-center p-20 text-xl bg-amber-500 ">Not Found</h1>
    </div>
  );
}

export default NotFound;